package com.phonemaster.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var ramText: TextView
    private lateinit var storageText: TextView
    private lateinit var batteryText: TextView
    private lateinit var deviceText: TextView
    private val bg = Color.rgb(13, 20, 17)
    private val panel = Color.rgb(25, 37, 31)
    private val green = Color.rgb(53, 208, 127)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun render() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(28))
        }
        scroll.addView(root)
        root.addView(label("PHONE MASTER", 26f, green, true))
        root.addView(label("أدوات مراقبة وصيانة لهاتفك", 14f, Color.LTGRAY).apply {
            setPadding(0, dp(5), 0, dp(20))
        })
        deviceText = label("", 13f, Color.LTGRAY)
        root.addView(card(deviceText))
        ramText = label("", 17f, Color.WHITE, true)
        root.addView(card(ramText))
        storageText = label("", 17f, Color.WHITE, true)
        root.addView(card(storageText))
        batteryText = label("", 17f, Color.WHITE, true)
        root.addView(card(batteryText))
        root.addView(label("أدوات النظام", 19f, green, true).apply {
            setPadding(0, dp(18), 0, dp(8))
        })
        addAction(root, "تحليل استهلاك التطبيقات", "يفتح إعدادات الوصول لبيانات الاستخدام") {
            try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            catch (_: Exception) { openAppSettings() }
        }
        addAction(root, "إدارة التطبيقات", "راجع التطبيقات واحذف أو أوقف ما لا تحتاجه") {
            startActivity(Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS))
        }
        addAction(root, "التخزين والملفات المؤقتة", "أدوات التخزين الرسمية في أندرويد") {
            try { startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        addAction(root, "البطارية وتوفير الطاقة", "راجع استهلاك البطارية وإعدادات التوفير") {
            startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        }
        addAction(root, "تحديث القراءات", "إعادة قراءة الذاكرة والتخزين والبطارية") { updateStats() }
        root.addView(label(
            "ملاحظة: أندرويد لا يسمح لتطبيق عادي بإغلاق عمليات التطبيقات الأخرى أو مسح كاشها بالقوة. هذه النسخة تعرض قراءات النظام وتفتح أدوات الصيانة الرسمية، بدون روت.",
            12f, Color.rgb(180, 195, 186)
        ).apply { setPadding(0, dp(18), 0, 0) })
        setContentView(scroll)
        updateStats()
    }

    private fun card(v: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        setBackgroundColor(panel)
        addView(v)
        val p = LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(10)
        layoutParams = p
    }

    private fun addAction(root: LinearLayout, title: String, sub: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(13))
            setBackgroundColor(panel)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
            addView(label(title, 16f, Color.WHITE, true))
            addView(label(sub, 12f, Color.LTGRAY).apply { setPadding(0, dp(4), 0, 0) })
        }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(9)
        root.addView(box, lp)
    }

    private fun updateStats() {
        deviceText.text = "الجهاز: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}"
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val total = mi.totalMem / 1024 / 1024
        val avail = mi.availMem / 1024 / 1024
        val used = total - avail
        ramText.text = "الذاكرة RAM\nالمستخدم تقريباً: ${used} MB من ${total} MB\nالمتاح: ${avail} MB"
        val stat = StatFs(Environment.getDataDirectory().path)
        val totalStorage = stat.totalBytes / 1024 / 1024 / 1024
        val freeStorage = stat.availableBytes / 1024 / 1024 / 1024
        storageText.text = "التخزين الداخلي\nالمتاح: ${freeStorage} GB من ${totalStorage} GB"
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val intent = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val tempText = if (temp > 0) String.format(Locale.US, "%.1f°C", temp / 10f) else "غير متاح"
        batteryText.text = "البطارية والحرارة\nالشحن: ${level}%\nحرارة البطارية: $tempText"
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = android.net.Uri.parse("package:$packageName")
        })
    }
}